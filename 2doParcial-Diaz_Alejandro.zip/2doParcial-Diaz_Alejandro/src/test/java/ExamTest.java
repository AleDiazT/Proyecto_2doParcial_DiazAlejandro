import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.YourCartPage;
import utilities.DriverManager;

import java.util.Map;

public class ExamTest extends BaseTest {

    @Test
    public void verifyProductIsRemovedFromYourCartPage() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);

        //Loguearse con las siguientes credenciales: standard_user, secret_sauce
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);

        //Agregar 2 o mas productos al carrito desde el home page
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        Map<String, String> priceHomePage = homePage.getPricesDictionary();

        //Ir al carrito
        homePage.clickOnShoppingCartButton();

        YourCartPage yourCartPage = new YourCartPage(DriverManager.getDriver().driver);

        //Verificar que los 2 items agregados estan en el carrito
        Assertions.assertTrue(yourCartPage.isProductDisplayed("Sauce Labs Fleece Jacket"));
        Assertions.assertTrue(yourCartPage.isProductDisplayed("Sauce Labs Bike Light"));

        //Verificar que el precio sea correcto de los items agregados
        Map<String, String> priceCartPage = yourCartPage.getPricesDictionary();
        Assertions.assertTrue(priceHomePage.values().containsAll(priceCartPage.values()));

        //Verificar que el icono del carrito tiene el numero correcto en base a cuantos items fueron seleccionados
        Assertions.assertTrue(yourCartPage.isShoppingCartNumberCorrect());

        //Remover los items agregados
        yourCartPage.removeProduct("Sauce Labs Fleece Jacket");
        yourCartPage.removeProduct("Sauce Labs Bike Light");

        //Verificar que los items fueron removidos
        Assertions.assertFalse((yourCartPage.isProductDisplayed("Sauce Labs Fleece Jacket")));
        Assertions.assertFalse((yourCartPage.isProductDisplayed("Sauce Labs Bike Light")));

        //Verificar que el icono del carrito no tiene ningun numero
        Assertions.assertTrue(yourCartPage.isShoppingCartEmpty());
    }
}