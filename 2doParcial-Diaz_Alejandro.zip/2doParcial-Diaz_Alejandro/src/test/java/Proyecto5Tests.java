import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pages.HomePage;
import pages.InformationPage;
import pages.LoginPage;
import pages.YourCartPage;
import pages.OverviewPage;
import pages.CompletePage;
import utilities.DriverManager;

import java.util.Map;

public class Proyecto5Tests extends BaseTest{

    @Test
    public void verifyResetAppState() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        homePage.clickOnBurgerButton();
        homePage.clickOnResetAppState();
        Map<String, String> priceHomePage = homePage.getPricesDictionary();
        Assertions.assertTrue(homePage.isShoppingCartEmpty());
        Assertions.assertTrue(priceHomePage.isEmpty());
    }

    @Test
    public void verifyWrongInformationPage() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        homePage.clickOnShoppingCartButton();

        YourCartPage yourCartPage = new YourCartPage(DriverManager.getDriver().driver);
        yourCartPage.clickCheckoutButton();

        InformationPage informationPage = new InformationPage(DriverManager.getDriver().driver);
        informationPage.setFirstName("12312");
        informationPage.setLastName("42343");
        informationPage.setPostalCode("Texto");
        informationPage.clickContinueButton();

        OverviewPage overviewPage = new OverviewPage(DriverManager.getDriver().driver);
        Assertions.assertFalse(overviewPage.pageTitleIsDisplayed());
    }

    @Test
    public void verifyOverviewTotalPrice() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        homePage.clickOnShoppingCartButton();

        YourCartPage yourCartPage = new YourCartPage(DriverManager.getDriver().driver);
        yourCartPage.clickCheckoutButton();

        InformationPage informationPage = new InformationPage(DriverManager.getDriver().driver);
        informationPage.setFirstName("Mariana");
        informationPage.setLastName("Vargas");
        informationPage.setPostalCode("3312");
        informationPage.clickContinueButton();

        OverviewPage overviewPage = new OverviewPage(DriverManager.getDriver().driver);
        Assertions.assertTrue(overviewPage.totalPriceVerification());
    }

    @Test
    public void verifyCancelOverviewButton() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        homePage.clickOnShoppingCartButton();

        YourCartPage yourCartPage = new YourCartPage(DriverManager.getDriver().driver);
        yourCartPage.clickCheckoutButton();

        InformationPage informationPage = new InformationPage(DriverManager.getDriver().driver);
        informationPage.setFirstName("Mariana");
        informationPage.setLastName("Vargas");
        informationPage.setPostalCode("3312");
        informationPage.clickContinueButton();

        OverviewPage overviewPage = new OverviewPage(DriverManager.getDriver().driver);
        overviewPage.clickCancelButton();

        HomePage homePage2 = new HomePage(DriverManager.getDriver().driver);
        Assertions.assertTrue(homePage2.pageTitleIsDisplayed());
    }

    @Test
    public void verifyBuyingProducts() throws InterruptedException {
        LoginPage loginPage = new LoginPage(DriverManager.getDriver().driver);
        loginPage.setUserNameTextBox("standard_user");
        loginPage.setPasswordTextBox("secret_sauce");
        loginPage.clickOnLoginButton();

        HomePage homePage = new HomePage(DriverManager.getDriver().driver);
        homePage.addProductToCart("Sauce Labs Fleece Jacket");
        homePage.addProductToCart("Sauce Labs Bike Light");
        homePage.clickOnShoppingCartButton();

        YourCartPage yourCartPage = new YourCartPage(DriverManager.getDriver().driver);
        yourCartPage.clickCheckoutButton();

        InformationPage informationPage = new InformationPage(DriverManager.getDriver().driver);
        informationPage.setFirstName("Mariana");
        informationPage.setLastName("Vargas");
        informationPage.setPostalCode("3312");
        informationPage.clickContinueButton();

        OverviewPage overviewPage = new OverviewPage(DriverManager.getDriver().driver);
        overviewPage.clickFinishButton();

        CompletePage completePage = new CompletePage(DriverManager.getDriver().driver);
        Assertions.assertTrue(completePage.thanksMessageIsDisplayed());
    }
}
