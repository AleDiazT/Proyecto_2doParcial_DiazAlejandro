package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OverviewPage {
    WebDriver driver;

    @FindBy(id = "finish")
    WebElement finishButton;

    @FindBy(className = "title")
    WebElement pageTitle;

    @FindBy(id = "cancel")
    WebElement cancelButton;

    @FindBy(className = "summary_subtotal_label")
    WebElement totalprice;

    @FindBy(className = "inventory_item_price")
    List<WebElement> productPrices;

    public OverviewPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickFinishButton(){
        finishButton.click();
    }

    public void clickCancelButton(){
        cancelButton.click();
    }

    public boolean pageTitleIsDisplayed(){
        boolean pageTitleIsDisplayed = pageTitle.isDisplayed();
        return pageTitleIsDisplayed;
    }

    public double sumPrices() {

        double total = 0;

        for (WebElement priceElement : productPrices) {
            String priceText = priceElement.getText();
            double price = Double.parseDouble(priceText.substring(1));
            total += price;
        }
        return total;
    }
    public double getPrice() {

        String text = totalprice.getText();

        Pattern p = Pattern.compile("\\$([0-9.]+)");
        Matcher m = p.matcher(text);
        double price = 0;
        if (m.find()) {
            price = Double.parseDouble(m.group(1));
        }
        return price;

    }

    public boolean totalPriceVerification(){
        return sumPrices() == getPrice();
    }
}
